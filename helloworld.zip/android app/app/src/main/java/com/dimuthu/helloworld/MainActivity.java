package com.dimuthu.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button manage1 , location1 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        manage1=findViewById(R.id.manage);
        location1 = findViewById(R.id.location);

        manage1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mang = new Intent(MainActivity.this,Manage.class);
                startActivity(mang);

            }
        });
        location1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lcn = new Intent(MainActivity.this,location.class);
                startActivity(lcn);
            }
        });

    }
}